<div class="col-md-3">
  <?php dynamic_sidebar('sidebar'); ?>
</div>