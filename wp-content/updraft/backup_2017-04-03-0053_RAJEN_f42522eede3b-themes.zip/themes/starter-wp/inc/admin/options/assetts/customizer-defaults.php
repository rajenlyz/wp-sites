<?php
//add settings default value
$background_color = '#ffffff';

$header_background_color = '#ffffff';
$header_text_color = '#666666';
$header_link_normal = '#3d3d3d';
$header_link_hover = '#00A1CB';

$body_text_color = '#666666';
$body_headings_color = '#3d3d3d';
$body_link_normal = '#3d3d3d';
$body_link_hover = '#00A1CB';

$footer_background_color =  '#ffffff';
$footer_text_color =  '#666666';
$footer_headings_color = '#3d3d3d';
$footer_link_normal = '#3d3d3d';
$footer_link_hover = '#00A1CB';

$button_background_normal = '#00A1CB';
$button_background_hover = '#008db2';
$button_text_normal =  '#ffffff';
$button_text_hover = '#ffffff';