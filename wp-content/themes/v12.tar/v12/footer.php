</div>
</div>
    <div class="v12-footer">
      <div class="container">
        <div class="row">
         <!--  <div class="col-md-12"><?php _e('Powered by ', 'v12'); ?><a href="http://www.wordpress.org"><?php _e('WordPress', 'v12'); ?></a> <?php _e('and', 'v12'); ?> <a href="http://v12theme.com"><?php _e('V12 Theme', 'v12'); ?></a></div>
        </div> -->
      </div>
    </div>
    <?php wp_footer(); ?>
  </body>
</html>
